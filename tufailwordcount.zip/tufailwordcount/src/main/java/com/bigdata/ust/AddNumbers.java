package com.bigdata.ust;

public class AddNumbers {

	//2 , 2, 2 = 6
	public int sum(int num1,int num2,int num3)
	{
		return num1+num2+num3;
	}
	//JUnit
}
