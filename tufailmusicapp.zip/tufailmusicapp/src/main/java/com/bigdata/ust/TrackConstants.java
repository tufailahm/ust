package com.bigdata.ust;

public class TrackConstants {

		public static int USER_ID = 0;
		public static int TRACK_ID = 1;
		public static int IS_SCROBBLED = 2;
		public static int RADIO = 3;
		public static int USER_SKIPPED = 4;
}
