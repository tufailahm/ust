package com.bigdata.ust;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CallLogMapper extends Mapper<Object, Text, Text, LongWritable> {
	@Override
	protected void map(Object key, Text value, Mapper<Object, Text, Text, LongWritable>.Context context)
			throws IOException, InterruptedException {

		LongWritable durationInMinutes = new LongWritable();
		String callStartTime;
		String callEndTime;
		String fromPhoneNumber;
		String[] line = value.toString().split("[|]");

		if (line[TrackConstants.callType].equalsIgnoreCase("1")) {
			// We are dealing with ISD calls
			callStartTime = line[TrackConstants.callStartTime];
			callEndTime = line[TrackConstants.callEndTime];
			fromPhoneNumber = line[TrackConstants.fromPhoneNumber];

			long callDurationinMillis = toMillis(callStartTime) - toMillis(callEndTime);
			durationInMinutes.set(callDurationinMillis / (100 * 60));
			context.write(new Text(fromPhoneNumber), durationInMinutes); // 8867205331
		}
	}

	private long toMillis(String date) {

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dateFrm = null;
		try {
			dateFrm = format.parse(date);

		} catch (ParseException e) {

			e.printStackTrace();
		}
		return dateFrm.getTime();
	}

}
