package com.bigdata.ust;

public enum COUNTERS {
		INVALID_RECORD_COUNT
}
