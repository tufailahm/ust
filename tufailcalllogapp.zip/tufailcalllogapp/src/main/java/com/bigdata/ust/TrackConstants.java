package com.bigdata.ust;

public class TrackConstants {

		public static int fromPhoneNumber = 0;
		public static int toPhoneNumber = 1;
		public static int callStartTime = 2;
		public static int callEndTime = 3;
		public static int callType = 4;
}
