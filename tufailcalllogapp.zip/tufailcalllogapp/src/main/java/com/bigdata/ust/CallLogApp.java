package com.bigdata.ust;

public class CallLogApp {

	public static void main(String[] args) {
		
		

	}

}
