package xmlparsing;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

//import mrdp.logging.LogWriter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class AhmedMapper extends Mapper<LongWritable, Text, Text, NullWritable> {

	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		InputStream is = new ByteArrayInputStream(value.toString().getBytes());
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Document doc = null;
		try {
			doc = dBuilder.parse(is);
		} catch (SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName("PRODUCT");
		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				String prodid = eElement.getElementsByTagName("PRODID").item(0).getTextContent();
				String category = eElement.getElementsByTagName("CATEGORY").item(0).getTextContent();
				String productname = eElement.getElementsByTagName("PRODUCTNAME").item(0).getTextContent();
				String description = eElement.getElementsByTagName("DESCRIPTION").item(0).getTextContent();
				String price = eElement.getElementsByTagName("PRICE").item(0).getTextContent();
				String quantity = eElement.getElementsByTagName("QUANTITY").item(0).getTextContent();

				context.write(new Text(prodid + ", " + category + ", " + productname + ", " + description + ", " + price
						+ ", " + quantity), NullWritable.get());
			}
		}
	}
}
