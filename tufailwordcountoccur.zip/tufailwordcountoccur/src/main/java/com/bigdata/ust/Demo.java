package com.bigdata.ust;

class TrackData
{
	public static int USER_ID = 0;
	public static int TRACK_ID = 1;
	public static int NOOFTIMESLISTENED = 2;
	public static int SKIPPED = 0;
}

class TrackEmp
{
	public static int EMP_ID =0;
	public static int EMP_NAME =1;
	public static int SALARY =2;
	public static int PF =3;
	public static int HRA =4;
}
public class Demo {

	public static void main(String[] args) {
	
		String parts[] = { "1", "100" , "90",  "12"};
	
		System.out.println(Integer.parseInt(parts[2])+Integer.parseInt(parts[3]));
		
		
		System.out.println(Integer.parseInt(parts[0])+Integer.parseInt(parts[1]));
		
		
		System.out.println(Integer.parseInt(parts[TrackData.USER_ID]) + Integer.parseInt(parts[TrackData.NOOFTIMESLISTENED]));
		
		
		String employeeData [] = { "90", "Mangai" , "98000", "988", "876"};
		
		// Mangai is getting total salary as : 98000+988+976
		System.out.println(employeeData[1] + "is getting total salary as :"+ ( Integer.parseInt(employeeData[2])+Integer.parseInt(employeeData[3])+Integer.parseInt(employeeData[4])));

		System.out.println(employeeData[TrackEmp.EMP_NAME] + "is getting total salary as :"+ ( Integer.parseInt(employeeData[TrackEmp.SALARY])+Integer.parseInt(employeeData[TrackEmp.PF])+Integer.parseInt(employeeData[TrackEmp.HRA])));

	}
}
