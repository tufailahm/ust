package com.bigdata.ust;

import java.util.ArrayList;
import java.util.List;

public class Demo1 {

	public static void main(String[] args) {
		String data = "K|Z|A|A";
		String [] p = data.split("[|]");
		
		List hs = new ArrayList();
		for(String s:p)
		{
			hs.add(s);
			
			System.out.println(s);
		}
	
		
		System.out.println("HashSet");
		System.out.println(hs);
	
	}
}
